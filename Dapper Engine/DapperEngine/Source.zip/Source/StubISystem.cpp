//------------------------------------------------------------------------------
//
// File Name:	NameHere.cpp
// Author(s):	
//						
//
// Copyright ?2021 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#include "NameHere.h"

// Dapper Namespace!
namespace Dapper 
{
    NameHere::NameHere()
    {
    }

    NameHere::~NameHere()
    {
    }

    const std::string& NameHere::Name() const
    {
        return name;
    }

    void NameHere::Initialize()
    {
    }

    void NameHere::Update(float dt)
    {
        dt;
    }

    void NameHere::Render()
    {
    }

} // End Of Dapper Namespace