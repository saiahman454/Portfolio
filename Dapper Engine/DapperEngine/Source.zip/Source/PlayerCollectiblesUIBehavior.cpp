//------------------------------------------------------------------------------
//
// File Name:	PlayerCollectiblesUIBehavior.cpp
// Author(s):	Natalie Bouley
//						
// Copyright ?2021 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#include "PlayerCollectiblesUIBehavior.h"
#include "ComponentRegistry.h"
#include "Utility.h"
#include "UIManager.h"
#include "imgui.h"
#include "Utility.h"
#include "PlayerController.h"
#include "GameObjectManager.h"
#include "SpriteText.h"
#include "SpriteTextManager.h"

// Dapper Namespace!
namespace Dapper 
{
	PlayerCollectiblesUIBehavior::PlayerCollectiblesUIBehavior(int ID, Engine* theEngine) :
		engine(theEngine),
		paused(false),
		my_ID(ID),
		parent_ID(-1),
		num_collectibles(0),
		parent_spritetext_ID(0)
	{
	}

	PlayerCollectiblesUIBehavior::~PlayerCollectiblesUIBehavior()
	{
	}

	void PlayerCollectiblesUIBehavior::Init()
	{
		parent_spritetext_ID = GetComponentFromParent<SpriteText>(*engine, parent_ID, "SpriteText")->GetID();

		// Register message that will increase number of collectibles on collision with collectible
		GameObjectManager& gameobject_manager = *GetSystemFromEngine<GameObjectManager*>(*engine, "GameObjectManager");
		int player_ID = gameobject_manager.FindObjectWithTag("Player");
		PlayerController& player_controller = *GetComponentFromParent<PlayerController>(*engine, player_ID, "PlayerController");
		player_controller.RegisterMessage(std::bind(&PlayerCollectiblesUIBehavior::OnCollection, this));

		// Update the Sprite Text to have the number of collectibles
		SpriteTextManager* spritetext_manager = GetSystemFromEngine<SpriteTextManager*>(*engine, "SpriteTextManager");
		SpriteText& spritetext = (*spritetext_manager)[parent_spritetext_ID];
		std::string new_string = std::to_string(num_collectibles);
		spritetext.SetText(new_string);
	}

	void PlayerCollectiblesUIBehavior::Update(float dt)
	{
	}

	void PlayerCollectiblesUIBehavior::Read(Deserializer& deserial, const rapidjson::Value& jsonVal)
	{
		deserial;
		//auto object = jsonVal.GetObject();
		//auto collectibles = object["NumCollectibles"].GetInt();
		//num_collectibles = collectibles;
	}

	void PlayerCollectiblesUIBehavior::Write(IJsonWriter& writer) const
	{
		writer.WriteKey("PlayerCollectiblesUIBehavior");
		writer.StartObject();
		//writer.WriteInt("NumCollectibles", num_collectibles);
		writer.EndObject();
	}

	void PlayerCollectiblesUIBehavior::ImGuiDisplay(float scale)
	{
	}

	void PlayerCollectiblesUIBehavior::OnCollection()
	{
		num_collectibles++;
		// Update the Sprite Text to have the number of collectibles
		SpriteTextManager* spritetext_manager = GetSystemFromEngine<SpriteTextManager*>(*engine, "SpriteTextManager");
		SpriteText& spritetext = (*spritetext_manager)[parent_spritetext_ID];
		std::string new_string = std::to_string(num_collectibles);
		spritetext.SetText(new_string);
	}

} // End Of Dapper Namespace