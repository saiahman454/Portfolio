//------------------------------------------------------------------------------
//
// File Name:	Messenger.h
// Author(s):	Isaiah
//						
//						
//
// Copyright ?2021 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once
#include <vector>
#include <functional>
#include "IDManager.h"
//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------

// Dapper Namespace!
namespace Dapper {
  template <typename ... Args>
  class Messenger
  {
  public:
    using func = std::function<void(Args...)>;
    int RegisterMessage(func frunk)
    {
      //functions.push_back(frunk);
        return theManager.Create(functions, frunk);
    }

    void SendMessage(Args... args)
    {
      for (unsigned i = 0; i < functions.size(); ++i)
      {
        functions[i](std::forward<Args>(args)...);
      }
    }
    void Remove(int Id)
    {
        theManager.Destroy(functions, Id);
    }
  private:
    std::vector<func> functions;
    IDManager theManager;

  };


} // End Of Dapper Namespace

//------------------------------------------------------------------------------


