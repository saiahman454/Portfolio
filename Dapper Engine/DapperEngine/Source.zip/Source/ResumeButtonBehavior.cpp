//------------------------------------------------------------------------------
//
// File Name:	NavButtonBehavior.cpp
// Author(s):	Adam Tackett
//						
// Copyright ?2021 DigiPen (USA) Corporation.
//------------------------------------------------------------------------------

#include "ResumeButtonBehavior.h"
#include "imgui.h"
#include "imgui_stdlib.h"
#include "Utility.h"
#include "Input.h"
#include "SceneManager.h"
#include "Engine.h"
#include "Transform.h"

// Dapper Namespace!
namespace Dapper {
    ResumeButtonBehavior::ResumeButtonBehavior(int ID_, Engine& engine_)
    : Button(ID_, engine_), engine(engine_)
  {
  }

    ResumeButtonBehavior::~ResumeButtonBehavior()
  {
  }


  void ResumeButtonBehavior::Init()
  {
      //Bind connects a function and a given this pointer / parameters(std::placeholder)
      Button::Init();
      Button::onReleased.RegisterMessage
      (std::bind(&ResumeButtonBehavior::Resume, this));
  }

  const std::string& ResumeButtonBehavior::GetName() const
  {
    return name;
  }

  void ResumeButtonBehavior::Update(float dt)
  {
    dt;
    Button::Update(dt);

  }

  void ResumeButtonBehavior::Read(Deserializer& deserial, const rapidjson::Value& jsonVal)
  {
    deserial, jsonVal;

    auto obj = jsonVal.GetObject();
    toResume = jsonVal["GameState"].GetString();
    Button::Read(deserial, jsonVal);

  }

  void ResumeButtonBehavior::Write(IJsonWriter& writer) const
  {
    // Write all of the values to the json file.
    writer.WriteKey("ResumeButtonBehavior");
    writer.StartObject();
    writer.WriteString("GameState", toResume.c_str());
    Button::Write(writer);
    writer.EndObject();
  }

  void ResumeButtonBehavior::ImGuiDisplay(float scale)
  {
    // Display editable values as float inputs.
    scale;
  }

  void ResumeButtonBehavior::Resume() const
  {
      SceneManager& state =
          *GetSystemFromEngine<SceneManager*>(engine, "SceneManager");
      int toUnload = state.SceneInCharge(GetParentID());

      state.UnloadScene(toUnload);

      if (toResume.empty())
      {
        state.UnPauseAllScenes();
        state.setEnableSceneAll(true);
      }
      else
      {
          Scene& resume = state.GetScene(toResume);
          resume.setEnableScene(true);
          resume.setPaused(false);
      }
  }

} // End Of Dapper Namespace