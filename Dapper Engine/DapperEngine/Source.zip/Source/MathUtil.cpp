//------------------------------------------------------------------------------
//
// File Name:	MathUtil.cpp
// Author(s):	Jacob Varboncoeur
//						
//	Contains Miscellaneous Math Functions
//
// Copyright ?2021 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------
#include "MathUtil.h"

namespace Dapper
{
	//template<typename vecType>
	//float EasyDistance(vecType origin, vecType target)
	


	
}