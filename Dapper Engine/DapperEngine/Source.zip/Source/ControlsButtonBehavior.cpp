//------------------------------------------------------------------------------
//
// File Name:	ControlsButtonBehavior.cpp
// Author(s):	Adam Tackett
//						
// Copyright ?2021 DigiPen (USA) Corporation.
//------------------------------------------------------------------------------

#include "ControlsButtonBehavior.h"
#include "imgui.h"
#include "imgui_stdlib.h"
#include "Utility.h"
#include "Input.h"
#include "SceneManager.h"
#include "Engine.h"
#include "Transform.h"

// Dapper Namespace!
namespace Dapper {
    ControlsButtonBehavior::ControlsButtonBehavior(int ID_, Engine& engine_)
    : Button(ID_, engine_), engine(engine_)
  {
  }

    ControlsButtonBehavior::~ControlsButtonBehavior()
  {
  }


  void ControlsButtonBehavior::Init()
  {
      //Bind connects a function and a given this pointer / parameters(std::placeholder)
      Button::onReleased.RegisterMessage
      (std::bind(&ControlsButtonBehavior::ChangeGameState, this));
  }

  const std::string& ControlsButtonBehavior::GetName() const
  {
    return name;
  }

  void ControlsButtonBehavior::Update(float dt)
  {
    dt;
    Button::Update(dt);

  }

  void ControlsButtonBehavior::Read(Deserializer& deserial, const rapidjson::Value& jsonVal)
  {
    deserial, jsonVal;

    auto obj = jsonVal.GetObject();
    gameState = jsonVal["GameState"].GetString();
    Button::Read(deserial, jsonVal);

  }

  void ControlsButtonBehavior::Write(IJsonWriter& writer) const
  {
    // Write all of the values to the json file.
    writer.WriteKey("ControlsButtonBehavior");
    writer.StartObject();
    writer.WriteString("GameState", gameState.c_str());
    //Button::Write() //Adam add for sprites
    Button::Write(writer);
    writer.EndObject();
  }

  void ControlsButtonBehavior::ImGuiDisplay(float scale)
  {
    // Display editable values as float inputs.
    scale;
    ImGui::InputText("GameState", &gameState);

  }

  void ControlsButtonBehavior::ChangeGameState() const
  {
      SceneManager& state =
          *GetSystemFromEngine<SceneManager*>(engine, "SceneManager");
      state.PauseAllScenes();
      state.setEnableSceneAll(false);
      state.LoadScene(gameState);
  }

} // End Of Dapper Namespace