//------------------------------------------------------------------------------
//
// File Name:	ExitButtonBehavior.cpp
// Author(s):	Adam Tackett
//						
// Copyright ?2021 DigiPen (USA) Corporation.
//------------------------------------------------------------------------------

#include "ExitButtonBehavior.h"
#include "imgui.h"
#include "imgui_stdlib.h"
#include "Utility.h"
#include "Input.h"
#include "SceneManager.h"
#include "Engine.h"
#include "Transform.h"


// Dapper Namespace!
namespace Dapper {
    ExitButtonBehavior::ExitButtonBehavior(int ID_, Engine& engine_)
    : Button(ID_, engine_), engine(engine_)
  {
  }

    ExitButtonBehavior::~ExitButtonBehavior()
  {
  }


  void ExitButtonBehavior::Init()
  {
      //Bind connects a function and a given this pointer / parameters(std::placeholder)
      Button::onReleased.RegisterMessage
      (std::bind(&ExitButtonBehavior::ChangeGameState, this));
  }

  const std::string& ExitButtonBehavior::GetName() const
  {
    return name;
  }

  void ExitButtonBehavior::Update(float dt)
  {
    dt;
    Button::Update(dt);

  }

  void ExitButtonBehavior::Read(Deserializer& deserial, const rapidjson::Value& jsonVal)
  {
    deserial, jsonVal;

    auto obj = jsonVal.GetObject();
    gameState = jsonVal["GameState"].GetString();
    Button::Read(deserial, jsonVal);

  }

  void ExitButtonBehavior::Write(IJsonWriter& writer) const
  {
    // Write all of the values to the json file.
    writer.WriteKey("ExitButtonBehavior");
    writer.StartObject();
    writer.WriteString("GameState", gameState.c_str());
    Button::Write(writer);
    writer.EndObject();
  }

  void ExitButtonBehavior::ImGuiDisplay(float scale)
  {
    // Display editable values as float inputs.
    scale;
    ImGui::InputText("GameState", &gameState);
  }

  void ExitButtonBehavior::ChangeGameState() const
  {
      SceneManager& state =
          *GetSystemFromEngine<SceneManager*>(engine, "SceneManager");
      state.UnloadAllScenes();
      state.LoadScene(gameState);
  }

} // End Of Dapper Namespace